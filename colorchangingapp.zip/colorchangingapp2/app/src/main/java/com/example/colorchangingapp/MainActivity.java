package com.example.colorchangingapp;

import android.os.Bundle;
import android.graphics.Color;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //initialize colorView
        findViewById(R.id.colorView);

        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.color_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        View colorView = findViewById(R.id.colorView);

        int itemId = item.getItemId();

        if (itemId == R.id.colorRed) {
            colorView.setBackgroundColor(Color.RED);
            return true;
        } else if (itemId == R.id.colorGreen) {
            colorView.setBackgroundColor(Color.GREEN);
            return true;
        } else if (itemId == R.id.colorBlue) {
            colorView.setBackgroundColor(Color.BLUE);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }

    }

}
